# Start here

The local project is ready to review. Public deployment is still to be done.

## Open your work

1. Open `Tourism_Project.html` in a browser to read the executed project.
2. Open `Tourism_Project.ipynb` in Jupyter to edit or rerun it.
3. Read the observations after each code cell. Make sure you can explain the choices
   and results in your own words before submitting it.

## Create your accounts

1. Go to https://github.com/signup and create a free GitHub account.
2. Complete the email verification yourself. Keep your password private.
3. Go to https://share.streamlit.io and sign in using GitHub.

## Put the project on GitHub

GitHub Desktop is an optional simple way to upload the complete folder, including
the hidden workflow folder: https://desktop.github.com/.

1. Sign in to GitHub Desktop with your account.
2. Add the extracted `tourism-purchase-prediction` folder as a local repository.
   If it is not yet a Git repository, use the offered option to create one there.
3. Check that `tourism_project` and `.github/workflows/pipeline.yml` are included.
4. Commit the files and publish the repository as public. Use the name
   `tourism-purchase-prediction` and the default branch `main`.
5. Open the repository on GitHub, select Actions, then Tourism Project Pipeline.
   Use Run workflow if the first run has not started. Wait for all jobs to pass.
6. If a run fails, open its red step and share the error text for troubleshooting.
   Do not record a failed run as successful evidence.

## Deploy the app

1. In Streamlit Community Cloud, choose Create app.
2. Select your GitHub repository and branch `main`.
3. Set the app file to `tourism_project/deployment/app.py`.
4. In advanced settings, select Python 3.13, then deploy.
5. Wait for the app to open. Enter sample values and test Predict purchase.
6. Confirm the app is public and copy its `streamlit.app` address.

## Finish the required submission

The course requests one HTML notebook. Before submitting, add the real GitHub repository
link, successful workflow link and public Streamlit link. Also add three screenshots:
the GitHub folder structure, the completed workflow and the deployed app.

Save screenshots under `evidence/`, fill `deployment_evidence.json`, and rerun the
Output Evaluation cell in the notebook. Export the updated notebook as HTML.
The current HTML clearly marks those items as pending. It is not yet a complete
cloud-deployment submission and those rubric points still need evidence.

The full technical run commands and references are in `README.md`.
